<template> 
  <member-detail :is-edit='true'></member-detail>
</template>
<script>
  import MemberDetail from './components/MemberDetail'
  export default {
    name: 'updateMember',
    components: { MemberDetail }
  }
</script>
<style>
</style>


