<template> 
  <memberLevel-detail :is-edit='true'></memberLevel-detail>
</template>
<script>
  import MemberLevelDetail from './components/MemberLevelDetail'
  export default {
    name: 'updateMemberLevel',
    components: { MemberLevelDetail }
  }
</script>
<style>
</style>


