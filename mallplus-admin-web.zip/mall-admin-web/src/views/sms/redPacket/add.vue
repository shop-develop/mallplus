<template> 
  <redPacket-detail :is-edit='false'></redPacket-detail>
</template>
<script>
  import RedPacketDetail from './components/RedPacketDetail'
  export default {
    name: 'addRedPacket',
    components: { RedPacketDetail }
  }
</script>
<style>
</style>


