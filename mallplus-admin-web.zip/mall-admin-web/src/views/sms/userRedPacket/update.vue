<template> 
  <userRedPacket-detail :is-edit='true'></userRedPacket-detail>
</template>
<script>
  import UserRedPacketDetail from './components/UserRedPacketDetail'
  export default {
    name: 'updateUserRedPacket',
    components: { UserRedPacketDetail }
  }
</script>
<style>
</style>


