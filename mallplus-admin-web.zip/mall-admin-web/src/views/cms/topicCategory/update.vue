<template> 
  <topicCategory-detail :is-edit='true'></topicCategory-detail>
</template>
<script>
  import TopicCategoryDetail from './components/TopicCategoryDetail'
  export default {
    name: 'updateTopicCategory',
    components: { TopicCategoryDetail }
  }
</script>
<style>
</style>


