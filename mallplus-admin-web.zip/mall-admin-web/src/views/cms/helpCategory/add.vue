<template> 
  <helpCategory-detail :is-edit='false'></helpCategory-detail>
</template>
<script>
  import HelpCategoryDetail from './components/HelpCategoryDetail'
  export default {
    name: 'addHelpCategory',
    components: { HelpCategoryDetail }
  }
</script>
<style>
</style>


