<template> 
  <prefrenceArea-detail :is-edit='false'></prefrenceArea-detail>
</template>
<script>
  import PrefrenceAreaDetail from './components/PrefrenceAreaDetail'
  export default {
    name: 'addPrefrenceArea',
    components: { PrefrenceAreaDetail }
  }
</script>
<style>
</style>


