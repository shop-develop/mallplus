<template> 
  <help-detail :is-edit='false'></help-detail>
</template>
<script>
  import HelpDetail from './components/HelpDetail'
  export default {
    name: 'addHelp',
    components: { HelpDetail }
  }
</script>
<style>
</style>


