<template> 
  <memberReport-detail :is-edit='false'></memberReport-detail>
</template>
<script>
  import MemberReportDetail from './components/MemberReportDetail'
  export default {
    name: 'addMemberReport',
    components: { MemberReportDetail }
  }
</script>
<style>
</style>


