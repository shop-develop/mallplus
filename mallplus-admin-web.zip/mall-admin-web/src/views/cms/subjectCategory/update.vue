<template> 
  <subjectCategory-detail :is-edit='true'></subjectCategory-detail>
</template>
<script>
  import SubjectCategoryDetail from './components/SubjectCategoryDetail'
  export default {
    name: 'updateSubjectCategory',
    components: { SubjectCategoryDetail }
  }
</script>
<style>
</style>


